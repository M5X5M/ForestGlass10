-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.forestglass.data.** { *; }
-keep class * extends androidx.room.RoomDatabase
-keepattributes *Annotation*
-dontwarn android.webkit.**
