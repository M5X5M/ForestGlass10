package com.forestglass.ui.screens

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import com.forestglass.data.Lesson
import com.forestglass.ui.feedback.ForestHaptics
import com.forestglass.ui.glass.GlassCard
import com.forestglass.ui.glass.GlassTier
import com.forestglass.ui.theme.FIcon
import com.forestglass.ui.theme.ForestIcon
import com.forestglass.ui.theme.ForestMotion
import com.forestglass.ui.theme.ForestTokens
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

object PinStore {
    private const val PREFS = "forest_glass_prefs"
    private const val KEY_PIN = "emergency_pin"
    const val DEFAULT_PIN = "1234"

    fun load(context: Context): String {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PIN, DEFAULT_PIN)
            .orEmpty()
        return if (raw.length == 4 && raw.all { it.isDigit() }) raw else DEFAULT_PIN
    }

    fun save(context: Context, pin: String) {
        if (pin.length == 4 && pin.all { it.isDigit() }) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit { putString(KEY_PIN, pin) }
        }
    }
}

@Composable
fun FocusScreen(
    lesson: Lesson,
    savedPin: String,
    onExitFocus: () -> Unit,
    onOpenDecoy: () -> Unit,
    modifier: Modifier = Modifier
) {
    val view = LocalView.current
    var selectedMinutes by remember { mutableIntStateOf(25) }
    var remainingSeconds by remember { mutableIntStateOf(25 * 60) }
    var isRunning by remember { mutableStateOf(true) }
    var showPinPad by remember { mutableStateOf(false) }

    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    val shakeOffset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(isRunning, showPinPad) {
        while (isRunning && remainingSeconds > 0) {
            delay(1_000L)
            remainingSeconds--
        }
        if (remainingSeconds == 0 && isRunning) {
            isRunning = false
            ForestHaptics.success(view)
        }
    }

    BackHandler {
        showPinPad = true
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ForestTokens.BlackOled)
            .statusBarsPadding()
            .padding(ForestTokens.ScreenPadding),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassCard(
                    cornerRadius = 16.dp,
                    tier = GlassTier.Lite,
                    interactive = false
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ForestIcon(FIcon.LOCK, size = 16.dp, tint = ForestTokens.MintGlow)
                        Text(
                            text = "وضع التركيز نشط",
                            color = ForestTokens.MintGlow,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                GlassCard(
                    cornerRadius = 16.dp,
                    tier = GlassTier.Lite,
                    onClick = onOpenDecoy
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ForestIcon(FIcon.CALCULATOR, size = 16.dp, tint = ForestTokens.TextPrimary)
                        Text(
                            text = "شاشة التمويه",
                            color = ForestTokens.TextPrimary,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            GlassCard(
                cornerRadius = 30.dp,
                selected = isRunning,
                onClick = { isRunning = !isRunning },
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 34.dp, horizontal = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = lesson.title,
                        color = ForestTokens.TextSecondary,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    val mins = remainingSeconds / 60
                    val secs = remainingSeconds % 60
                    Text(
                        text = "%02d:%02d".format(mins, secs),
                        color = ForestTokens.TextPrimary,
                        fontSize = 54.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = if (isRunning) "اضغط للإيقاف المؤقت" else "متوقف مؤقتاً · اضغط للاستمرار",
                        color = ForestTokens.MintGlow,
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf(25, 45, 60).forEach { preset ->
                            val active = selectedMinutes == preset
                            GlassCard(
                                cornerRadius = 14.dp,
                                tier = GlassTier.Lite,
                                selected = active,
                                onClick = {
                                    selectedMinutes = preset
                                    remainingSeconds = preset * 60
                                    isRunning = true
                                }
                            ) {
                                Text(
                                    text = "$preset د",
                                    color = if (active) ForestTokens.MintGlow else ForestTokens.TextSecondary,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            GlassCard(
                cornerRadius = 20.dp,
                tier = GlassTier.Lite,
                onClick = {
                    enteredPin = ""
                    pinError = false
                    showPinPad = true
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 15.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "إنهاء جلسة التركيز (رمز الخروج)",
                        color = ForestTokens.TextSecondary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = showPinPad,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(150))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.88f)),
                contentAlignment = Alignment.Center
            ) {
                GlassCard(
                    cornerRadius = 28.dp,
                    interactive = false,
                    modifier = Modifier
                        .widthIn(max = 360.dp)
                        .fillMaxWidth()
                        .offset { IntOffset(shakeOffset.value.roundToInt(), 0) }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "رمز الخروج",
                            color = ForestTokens.TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = if (pinError) "الرمز غير صحيح، حاول مجدداً" else "أدخل الرمز المكون من 4 أرقام",
                            color = if (pinError) ForestTokens.Danger else ForestTokens.TextSecondary,
                            fontSize = 13.sp
                        )

                        Spacer(Modifier.height(20.dp))

                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                repeat(4) { index ->
                                    val filled = index < enteredPin.length
                                    val dotScale by animateFloatAsState(
                                        targetValue = if (filled) 1.25f else 1f,
                                        animationSpec = ForestMotion.pulseSpring(),
                                        label = "pinDot"
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(14.dp)
                                            .graphicsLayer {
                                                scaleX = dotScale
                                                scaleY = dotScale
                                            }
                                            .background(
                                                when {
                                                    pinError -> ForestTokens.Danger
                                                    filled -> ForestTokens.MintGlow
                                                    else -> Color.Transparent
                                                },
                                                CircleShape
                                            )
                                            .border(
                                                1.5.dp,
                                                if (pinError) ForestTokens.Danger else ForestTokens.MintGlow,
                                                CircleShape
                                            )
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(24.dp))

                        LtrPinKeypad(
                            onDigit = { d ->
                                if (enteredPin.length < 4) {
                                    pinError = false
                                    val next = enteredPin + d
                                    enteredPin = next
                                    if (next.length == 4) {
                                        if (next == savedPin) {
                                            ForestHaptics.success(view)
                                            showPinPad = false
                                            onExitFocus()
                                        } else {
                                            ForestHaptics.error(view)
                                            pinError = true
                                            scope.launch {
                                                for (dx in listOf(-18f, 18f, -12f, 12f, -6f, 0f)) {
                                                    shakeOffset.animateTo(dx, tween(45))
                                                }
                                                enteredPin = ""
                                            }
                                        }
                                    }
                                }
                            },
                            onBackspace = {
                                if (enteredPin.isNotEmpty()) {
                                    enteredPin = enteredPin.dropLast(1)
                                    pinError = false
                                }
                            }
                        )

                        Spacer(Modifier.height(14.dp))

                        GlassCard(
                            cornerRadius = 16.dp,
                            tier = GlassTier.Lite,
                            onClick = { showPinPad = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "إلغاء",
                                    color = ForestTokens.TextSecondary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LtrPinKeypad(
    onDigit: (String) -> Unit,
    onBackspace: () -> Unit,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("", "0", "BACK")
        )
        Column(
            modifier = modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            rows.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    row.forEach { key ->
                        when (key) {
                            "" -> Spacer(Modifier.weight(1f).height(58.dp))
                            "BACK" -> {
                                GlassCard(
                                    cornerRadius = 18.dp,
                                    tier = GlassTier.Lite,
                                    onClick = onBackspace,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(58.dp)
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        ForestIcon(
                                            FIcon.BACKSPACE,
                                            size = 20.dp,
                                            tint = ForestTokens.TextSecondary
                                        )
                                    }
                                }
                            }
                            else -> {
                                GlassCard(
                                    cornerRadius = 18.dp,
                                    tier = GlassTier.Lite,
                                    onClick = { onDigit(key) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(58.dp)
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = key,
                                            color = ForestTokens.TextPrimary,
                                            fontSize = 22.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
