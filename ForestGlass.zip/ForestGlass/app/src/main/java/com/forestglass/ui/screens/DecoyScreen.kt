package com.forestglass.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.forestglass.ui.glass.GlassCard
import com.forestglass.ui.glass.GlassTier
import com.forestglass.ui.theme.ForestTokens

@Composable
fun DecoyScreen(
    secretPin: String,
    onUnlockSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    var display by remember { mutableStateOf("0") }
    var pendingOp by remember { mutableStateOf<Char?>(null) }
    var firstOperand by remember { mutableStateOf<Double?>(null) }
    var resetOnNextDigit by remember { mutableStateOf(false) }

    BackHandler { }

    fun formatResult(value: Double): String {
        val asLong = value.toLong()
        return if (value == asLong.toDouble()) asLong.toString() else "%.4f".format(value).trimEnd('0').trimEnd('.')
    }

    fun pressKey(key: String) {
        when (key) {
            "C" -> {
                display = "0"
                pendingOp = null
                firstOperand = null
                resetOnNextDigit = false
            }
            "⌫" -> {
                display = if (display.length <= 1) "0" else display.dropLast(1)
            }
            "+", "-", "×", "÷" -> {
                firstOperand = display.toDoubleOrNull() ?: 0.0
                pendingOp = key.first()
                resetOnNextDigit = true
            }
            "=" -> {
                if (pendingOp == null && display == secretPin) {
                    onUnlockSuccess()
                    return
                }
                val a = firstOperand ?: return
                val b = display.toDoubleOrNull() ?: 0.0
                val res = when (pendingOp) {
                    '+' -> a + b
                    '-' -> a - b
                    '×' -> a * b
                    '÷' -> if (b == 0.0) Double.NaN else a / b
                    else -> b
                }
                display = if (res.isNaN() || res.isInfinite()) "Error" else formatResult(res)
                pendingOp = null
                firstOperand = null
                resetOnNextDigit = true
            }
            "." -> {
                if (resetOnNextDigit) {
                    display = "0."
                    resetOnNextDigit = false
                } else if (!display.contains('.')) {
                    display += "."
                }
            }
            else -> {
                display = if (display == "0" || display == "Error" || resetOnNextDigit) {
                    resetOnNextDigit = false
                    key
                } else {
                    (display + key).take(12)
                }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ForestTokens.BlackOled)
            .statusBarsPadding()
            .padding(ForestTokens.ScreenPadding),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 460.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Bottom
        ) {
            GlassCard(
                cornerRadius = 26.dp,
                tier = GlassTier.Lite,
                interactive = false,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 26.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = pendingOp?.let { "${firstOperand?.let(::formatResult) ?: ""} $it" } ?: "",
                        color = ForestTokens.TextSecondary,
                        fontSize = 15.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = display,
                        color = ForestTokens.TextPrimary,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.End,
                        maxLines = 1
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                val pad = listOf(
                    listOf("C", "⌫", "÷", "×"),
                    listOf("7", "8", "9", "-"),
                    listOf("4", "5", "6", "+"),
                    listOf("1", "2", "3", "="),
                    listOf("0", ".")
                )
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    pad.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            row.forEach { label ->
                                val isOp = label in listOf("÷", "×", "-", "+", "=")
                                val weight = if (label == "0") 2f else 1f
                                GlassCard(
                                    cornerRadius = 20.dp,
                                    tier = GlassTier.Lite,
                                    selected = label == "=",
                                    onClick = { pressKey(label) },
                                    modifier = Modifier
                                        .weight(weight)
                                        .height(64.dp)
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (isOp) ForestTokens.MintGlow else ForestTokens.TextPrimary,
                                            fontSize = 22.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
    }
}
