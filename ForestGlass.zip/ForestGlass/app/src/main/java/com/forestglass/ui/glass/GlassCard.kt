package com.forestglass.ui.glass

import android.graphics.Paint
import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.forestglass.sensor.TiltState
import com.forestglass.ui.feedback.ForestHaptics
import com.forestglass.ui.theme.ForestMotion
import com.forestglass.ui.theme.ForestTokens

enum class GlassTier { Water, Lite }

val LocalTiltState = compositionLocalOf { TiltState() }
val LocalWaterPulse = compositionLocalOf { WaterPulseBus() }

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = ForestTokens.CardRadius,
    tier: GlassTier = GlassTier.Water,
    interactive: Boolean = true,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val view = LocalView.current
    val tilt = LocalTiltState.current
    val pulseBus = LocalWaterPulse.current
    val shape = RoundedCornerShape(cornerRadius)

    val waterState = remember { WaterState() }
    val runtimeShader = remember(tier) {
        if (tier == GlassTier.Water) WaterShaderFactory.createRuntimeShader() else null
    }
    val nativePaint = remember(runtimeShader) {
        if (runtimeShader != null) Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = runtimeShader } else null
    }

    var isHolding by remember { mutableStateOf(false) }

    val pressScale by animateFloatAsState(
        targetValue = if (interactive && isHolding) 0.978f else 1f,
        animationSpec = ForestMotion.tapSpring(),
        label = "glassPressScale"
    )
    val selectedAnim by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = ForestMotion.liquidSpring(),
        label = "glassSelected"
    )

    LaunchedEffect(pulseBus.sequence) {
        if (pulseBus.sequence > 0 && (selected || interactive)) {
            waterState.triggerExternalRipple(pulseBus.normX, pulseBus.normY, pulseBus.strength * 0.72f)
        }
    }

    val latestTilt by rememberUpdatedState(tilt)
    val shouldAnimateWave = waterState.isActive || tilt.x != 0f || tilt.y != 0f

    LaunchedEffect(shouldAnimateWave) {
        if (!shouldAnimateWave) return@LaunchedEffect
        var lastNs = 0L
        while (waterState.isActive || latestTilt.x != 0f || latestTilt.y != 0f) {
            withFrameNanos { ns ->
                val dt = if (lastNs == 0L) 1f / 60f else (ns - lastNs) / 1_000_000_000f
                lastNs = ns
                waterState.step(dt, latestTilt.x, latestTilt.y)
            }
        }
    }

    // Passive pointer tracker so finger movement & dragging spawns live water wakes + turquoise light
    val fingerTrackerModifier = if (interactive) {
        Modifier.pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    val change = event.changes.firstOrNull() ?: continue
                    val w = size.width.coerceAtLeast(1).toFloat()
                    val h = size.height.coerceAtLeast(1).toFloat()
                    val nx = change.position.x / w
                    val ny = change.position.y / h

                    when (event.type) {
                        PointerEventType.Press -> {
                            waterState.updatePointer(nx, ny, pressed = true, spawnSplash = true)
                        }
                        PointerEventType.Move -> {
                            waterState.updatePointer(nx, ny, pressed = change.pressed, spawnSplash = false)
                        }
                        PointerEventType.Release -> {
                            waterState.updatePointer(nx, ny, pressed = false, spawnSplash = true)
                        }
                        else -> Unit
                    }
                }
            }
        }
    } else {
        Modifier
    }

    val tapModifier = if (interactive || onClick != null) {
        Modifier.pointerInput(onClick, interactive) {
            detectTapGestures(
                onPress = {
                    if (interactive) isHolding = true
                    val released = tryAwaitRelease()
                    isHolding = false
                    if (released && onClick != null) {
                        ForestHaptics.tap(view)
                        onClick()
                    }
                }
            )
        }
    } else {
        Modifier
    }

    Box(
        modifier = modifier
            .graphicsLayer {
                val liftScale = pressScale * (1f + selectedAnim * 0.012f)
                scaleX = liftScale
                scaleY = liftScale
                translationY = -selectedAnim * 3.5f
            }
            .clip(shape)
            .drawBehind {
                val w = size.width
                val h = size.height
                if (w <= 1f || h <= 1f) return@drawBehind
                val rPx = cornerRadius.toPx()

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    runtimeShader != null &&
                    nativePaint != null &&
                    !WaterShaderFactory.agslFailed
                ) {
                    runCatching {
                        runtimeShader.setFloatUniform("uSize", w, h)
                        runtimeShader.setFloatUniform("uTouch", waterState.touchNormX, waterState.touchNormY)
                        runtimeShader.setFloatUniform("uTilt", waterState.sloshX, waterState.sloshY)
                        runtimeShader.setFloatUniform("uGlow", waterState.touchGlow)
                        runtimeShader.setFloatUniform("uSelected", selectedAnim)
                        runtimeShader.setFloatUniform("uRadius", rPx)
                        runtimeShader.setFloatUniform("uAmbientTime", waterState.ambientTime)
                        runtimeShader.setFloatUniform("uWave0", waterState.w0X, waterState.w0Y, waterState.w0Age, waterState.w0Amp)
                        runtimeShader.setFloatUniform("uWave1", waterState.w1X, waterState.w1Y, waterState.w1Age, waterState.w1Amp)
                        runtimeShader.setFloatUniform("uWave2", waterState.w2X, waterState.w2Y, waterState.w2Age, waterState.w2Amp)
                        drawIntoCanvas { canvas ->
                            canvas.nativeCanvas.drawRoundRect(0f, 0f, w, h, rPx, rPx, nativePaint)
                        }
                    }.onFailure {
                        drawFallbackGlass(w, h, tilt, waterState, selectedAnim)
                    }
                } else {
                    drawFallbackGlass(w, h, tilt, waterState, selectedAnim)
                }
            }
            .then(fingerTrackerModifier)
            .then(tapModifier),
        content = content
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawFallbackGlass(
    w: Float,
    h: Float,
    tilt: TiltState,
    water: WaterState,
    selectedAnim: Float
) {
    drawRect(brush = ForestTokens.GlassSurfaceLiteGradient)
    val ambientCenter = Offset(w * (0.5f + tilt.x * 0.25f), h * (0.18f + tilt.y * 0.2f))
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(
                ForestTokens.MintGlow.copy(alpha = 0.14f + selectedAnim * 0.16f),
                Color.Transparent
            ),
            center = ambientCenter,
            radius = maxOf(w, h) * 0.82f
        )
    )
    if (water.touchGlow > 0.01f) {
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(
                    ForestTokens.MintGlow.copy(alpha = water.touchGlow * 0.42f),
                    Color.Transparent
                ),
                center = Offset(w * water.touchNormX, h * water.touchNormY),
                radius = maxOf(w, h) * 0.62f
            )
        )
    }
}

@Composable
fun GlassSelectableRow(
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 14.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val view = LocalView.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val rowScale by animateFloatAsState(
        targetValue = if (pressed) 0.985f else 1f,
        animationSpec = ForestMotion.tapSpring(),
        label = "rowScale"
    )
    val bgColor by animateColorAsState(
        targetValue = when {
            pressed -> ForestTokens.MintPressed
            selected -> ForestTokens.MintSoft
            else -> Color.Transparent
        },
        animationSpec = ForestMotion.liquidSpring(),
        label = "rowGlow"
    )

    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = rowScale
                scaleY = rowScale
            }
            .clip(shape)
            .background(bgColor, shape)
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) {
                ForestHaptics.select(view)
                onClick()
            },
        content = content
    )
}
