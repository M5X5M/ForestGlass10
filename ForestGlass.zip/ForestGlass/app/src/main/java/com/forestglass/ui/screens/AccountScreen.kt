package com.forestglass.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.forestglass.CrashLog
import com.forestglass.ui.glass.GlassCard
import com.forestglass.ui.glass.GlassTier
import com.forestglass.ui.theme.ForestTokens

@Composable
fun AccountScreen(
    currentPin: String,
    onUpdatePin: (String) -> Unit,
    onResetProgress: () -> Unit,
    bottomPadding: PaddingValues,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var editingPin by remember { mutableStateOf(false) }
    var draftPin by remember { mutableStateOf("") }
    var confirmReset by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var crashReport by remember { mutableStateOf(CrashLog.read(context)) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = ForestTokens.ScreenPadding),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 860.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(
                top = 18.dp,
                bottom = bottomPadding.calculateBottomPadding() + 18.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "حسابي والإعدادات",
                    color = ForestTokens.TextPrimary,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (statusMessage != null) {
                item {
                    GlassCard(
                        cornerRadius = 18.dp,
                        selected = true,
                        interactive = false,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = statusMessage.orEmpty(),
                            color = ForestTokens.MintGlow,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            }

            item {
                GlassCard(
                    cornerRadius = ForestTokens.CardRadius,
                    tier = GlassTier.Lite,
                    onClick = {
                        draftPin = ""
                        editingPin = !editingPin
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "رمز الخروج الطارئ",
                                    color = ForestTokens.TextPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "يُستخدم للخروج من وضع التركيز أو شاشة التمويه",
                                    color = ForestTokens.TextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                            Text(
                                text = currentPin,
                                color = ForestTokens.MintGlow,
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        AnimatedVisibility(visible = editingPin) {
                            Column(modifier = Modifier.padding(top = 16.dp)) {
                                Text(
                                    text = "أدخل الرمز الجديد (4 أرقام): ${draftPin.padEnd(4, '•')}",
                                    color = ForestTokens.MintGlow,
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(Modifier.height(12.dp))
                                LtrPinKeypad(
                                    onDigit = { d ->
                                        if (draftPin.length < 4) {
                                            val next = draftPin + d
                                            draftPin = next
                                            if (next.length == 4) {
                                                onUpdatePin(next)
                                                editingPin = false
                                                statusMessage = "تم تحديث رمز الخروج إلى $next"
                                            }
                                        }
                                    },
                                    onBackspace = {
                                        if (draftPin.isNotEmpty()) draftPin = draftPin.dropLast(1)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            item {
                GlassCard(
                    cornerRadius = ForestTokens.CardRadius,
                    tier = GlassTier.Lite,
                    onClick = {
                        if (!confirmReset) {
                            confirmReset = true
                        } else {
                            onResetProgress()
                            confirmReset = false
                            statusMessage = "تم تصفير سجل التقدم الدراسي"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = if (confirmReset) "اضغط مرة أخرى لتأكيد تصفير التقدم" else "إعادة تعيين التقدم الدراسي",
                            color = if (confirmReset) ForestTokens.Danger else ForestTokens.TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            text = "يحذف ساعات المشاهدة وحالات الإنجاز المحفوظة محلياً",
                            color = ForestTokens.TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            if (crashReport != null) {
                item {
                    GlassCard(
                        cornerRadius = ForestTokens.CardRadius,
                        tier = GlassTier.Lite,
                        interactive = false,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "سجل آخر خطأ محفوظ",
                                color = ForestTokens.Warning,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = crashReport.orEmpty().take(500),
                                color = ForestTokens.TextSecondary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                GlassCard(
                                    cornerRadius = 14.dp,
                                    tier = GlassTier.Lite,
                                    onClick = {
                                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                        cm?.setPrimaryClip(ClipData.newPlainText("ForestGlassLog", crashReport))
                                        statusMessage = "تم نسخ سجل الخطأ"
                                    }
                                ) {
                                    Text(
                                        text = "نسخ السجل",
                                        color = ForestTokens.MintGlow,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                                GlassCard(
                                    cornerRadius = 14.dp,
                                    tier = GlassTier.Lite,
                                    onClick = {
                                        CrashLog.clear(context)
                                        crashReport = null
                                    }
                                ) {
                                    Text(
                                        text = "مسح",
                                        color = ForestTokens.TextSecondary,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
