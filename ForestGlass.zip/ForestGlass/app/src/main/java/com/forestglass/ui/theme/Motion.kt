package com.forestglass.ui.theme

import androidx.compose.animation.ContentTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.delay

object ForestMotion {
    val SmoothEasing = CubicBezierEasing(0.22f, 1.0f, 0.36f, 1.0f)

    fun <T> liquidSpring() = spring<T>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = 380f
    )

    fun <T> tapSpring() = spring<T>(
        dampingRatio = 0.68f,
        stiffness = 480f
    )

    fun <T> indicatorSpring() = spring<T>(
        dampingRatio = 0.76f,
        stiffness = 410f
    )

    fun <T> pulseSpring() = spring<T>(
        dampingRatio = 0.54f,
        stiffness = 480f
    )

    fun intOffsetSpring() = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = 420f
    )

    fun tabTransition(direction: Int): ContentTransform {
        val dir = if (direction >= 0) 1 else -1
        return (slideInHorizontally(
            animationSpec = tween(durationMillis = 280, easing = SmoothEasing),
            initialOffsetX = { fullWidth -> -(fullWidth / 8) * dir }
        ) + fadeIn(
            animationSpec = tween(durationMillis = 240, easing = SmoothEasing)
        ) + scaleIn(
            animationSpec = tween(durationMillis = 280, easing = SmoothEasing),
            initialScale = 0.975f
        )).togetherWith(
            slideOutHorizontally(
                animationSpec = tween(durationMillis = 220, easing = SmoothEasing),
                targetOffsetX = { fullWidth -> (fullWidth / 10) * dir }
            ) + fadeOut(
                animationSpec = tween(durationMillis = 170, easing = SmoothEasing)
            ) + scaleOut(
                animationSpec = tween(durationMillis = 220, easing = SmoothEasing),
                targetScale = 0.985f
            )
        )
    }

    val depthEnterTransition: ContentTransform
        get() = (fadeIn(
            animationSpec = tween(durationMillis = 260, easing = SmoothEasing)
        ) + scaleIn(
            animationSpec = tween(durationMillis = 280, easing = SmoothEasing),
            initialScale = 0.955f
        ) + slideInVertically(
            animationSpec = tween(durationMillis = 280, easing = SmoothEasing),
            initialOffsetY = { it / 18 }
        )).togetherWith(
            fadeOut(
                animationSpec = tween(durationMillis = 160, easing = SmoothEasing)
            ) + scaleOut(
                animationSpec = tween(durationMillis = 200, easing = SmoothEasing),
                targetScale = 0.98f
            )
        )

    val depthExitTransition: ContentTransform
        get() = (fadeIn(
            animationSpec = tween(durationMillis = 240, easing = SmoothEasing)
        ) + scaleIn(
            animationSpec = tween(durationMillis = 260, easing = SmoothEasing),
            initialScale = 0.975f
        )).togetherWith(
            fadeOut(
                animationSpec = tween(durationMillis = 170, easing = SmoothEasing)
            ) + slideOutVertically(
                animationSpec = tween(durationMillis = 220, easing = SmoothEasing),
                targetOffsetY = { it / 20 }
            ) + scaleOut(
                animationSpec = tween(durationMillis = 220, easing = SmoothEasing),
                targetScale = 0.96f
            )
        )
}

fun Modifier.fluidRise(stepIndex: Int = 0): Modifier = composed {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (stepIndex > 0) delay((stepIndex.coerceAtMost(10) * 42L))
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 360, easing = ForestMotion.SmoothEasing)
        )
    }
    val p = progress.value
    graphicsLayer {
        alpha = p
        translationY = (1f - p) * 28f
        val s = 0.965f + p * 0.035f
        scaleX = s
        scaleY = s
    }
}
