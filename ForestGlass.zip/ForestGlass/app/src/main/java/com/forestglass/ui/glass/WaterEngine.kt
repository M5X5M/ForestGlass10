package com.forestglass.ui.glass

import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * Shared water-ripple pulse bus triggered by keyboard input, navigation, and actions.
 */
@Stable
class WaterPulseBus {
    var sequence by mutableIntStateOf(0)
        private set
    var normX by mutableFloatStateOf(0.5f)
        private set
    var normY by mutableFloatStateOf(0.5f)
        private set
    var strength by mutableFloatStateOf(0.75f)
        private set

    fun emit(x: Float = 0.5f, y: Float = 0.5f, amp: Float = 0.72f) {
        normX = x.coerceIn(0.05f, 0.95f)
        normY = y.coerceIn(0.05f, 0.95f)
        strength = amp.coerceIn(0.2f, 1.0f)
        sequence++
    }
}

/**
 * Photorealistic GPU-driven water physics state:
 * - 3 simultaneous wave emitters with true wall-bounce reflection inside AGSL
 * - Spring-damped physical liquid slosh + tilt-driven ripples from device movement
 * - Continuous smooth turquoise illumination tracking finger touch, drag, & keyboard pulses
 */
@Stable
class WaterState {
    var touchNormX by mutableFloatStateOf(0.5f)
    var touchNormY by mutableFloatStateOf(0.5f)
    var touchGlow by mutableFloatStateOf(0f)
    var isPressed by mutableFloatStateOf(0f)
    var ambientTime by mutableFloatStateOf(0f)

    // Physical spring-damped water slosh (tilt rebound inertia)
    var sloshX by mutableFloatStateOf(0f)
    var sloshY by mutableFloatStateOf(0f)
    private var sloshVx = 0f
    private var sloshVy = 0f
    private var lastTiltX = 0f
    private var lastTiltY = 0f
    private var tiltRippleCooldown = 0f

    // 3 concurrent ripple slots (x, y, age, amp) for multi-touch & rebound
    var w0X by mutableFloatStateOf(0.5f)
    var w0Y by mutableFloatStateOf(0.5f)
    var w0Age by mutableFloatStateOf(0f)
    var w0Amp by mutableFloatStateOf(0f)

    var w1X by mutableFloatStateOf(0.5f)
    var w1Y by mutableFloatStateOf(0.5f)
    var w1Age by mutableFloatStateOf(0f)
    var w1Amp by mutableFloatStateOf(0f)

    var w2X by mutableFloatStateOf(0.5f)
    var w2Y by mutableFloatStateOf(0.5f)
    var w2Age by mutableFloatStateOf(0f)
    var w2Amp by mutableFloatStateOf(0f)

    private var nextSlot = 0
    private var lastRippleX = 0.5f
    private var lastRippleY = 0.5f
    private var motionHoldSeconds = 0f

    val isActive: Boolean
        get() = isPressed > 0.5f ||
            motionHoldSeconds > 0f ||
            touchGlow > 0.003f ||
            w0Amp > 0.003f ||
            w1Amp > 0.003f ||
            w2Amp > 0.003f ||
            abs(sloshVx) > 0.004f ||
            abs(sloshVy) > 0.004f

    fun updatePointer(normX: Float, normY: Float, pressed: Boolean, spawnSplash: Boolean) {
        val nx = normX.coerceIn(0.02f, 0.98f)
        val ny = normY.coerceIn(0.02f, 0.98f)
        val moved = hypot((nx - lastRippleX).toDouble(), (ny - lastRippleY).toDouble()).toFloat()
        touchNormX = nx
        touchNormY = ny
        isPressed = if (pressed) 1f else 0f

        if (pressed || moved > 0.004f) {
            touchGlow = 1f
            motionHoldSeconds = 0.38f
            if (spawnSplash || moved > 0.032f) {
                val amp = if (spawnSplash) 1.0f else min(0.82f, 0.36f + moved * 5.2f)
                spawnWave(nx, ny, amp)
                lastRippleX = nx
                lastRippleY = ny
            }
        }
    }

    fun triggerExternalRipple(normX: Float, normY: Float, amp: Float = 0.65f) {
        touchNormX = normX.coerceIn(0.05f, 0.95f)
        touchNormY = normY.coerceIn(0.05f, 0.95f)
        touchGlow = maxOf(touchGlow, amp * 0.95f)
        motionHoldSeconds = 0.38f
        spawnWave(touchNormX, touchNormY, amp)
    }

    private fun spawnWave(nx: Float, ny: Float, amp: Float) {
        when (nextSlot) {
            0 -> {
                w0X = nx; w0Y = ny; w0Age = 0f; w0Amp = amp
            }
            1 -> {
                w1X = nx; w1Y = ny; w1Age = 0f; w1Amp = amp
            }
            else -> {
                w2X = nx; w2Y = ny; w2Age = 0f; w2Amp = amp
            }
        }
        nextSlot = (nextSlot + 1) % 3
    }

    fun step(dtSeconds: Float, tiltX: Float = 0f, tiltY: Float = 0f) {
        val dt = dtSeconds.coerceIn(0.001f, 0.033f)
        ambientTime += dt

        // Second-order damped harmonic slosh rebound from device tilt
        val targetX = tiltX.coerceIn(-1f, 1f)
        val targetY = tiltY.coerceIn(-1f, 1f)
        val ax = (targetX - sloshX) * 32f - sloshVx * 4.4f
        val ay = (targetY - sloshY) * 32f - sloshVy * 4.4f
        sloshVx += ax * dt
        sloshVy += ay * dt
        sloshX += sloshVx * dt
        sloshY += sloshVy * dt

        // Device motion -> spawn organic edge-slosh water ripples on noticeable tilt change
        if (tiltRippleCooldown > 0f) {
            tiltRippleCooldown -= dt
        } else {
            val dTilt = hypot((targetX - lastTiltX).toDouble(), (targetY - lastTiltY).toDouble()).toFloat()
            if (dTilt > 0.10f) {
                val edgeX = (0.5f + targetX * 0.38f).coerceIn(0.1f, 0.9f)
                val edgeY = (0.5f + targetY * 0.38f).coerceIn(0.1f, 0.9f)
                spawnWave(edgeX, edgeY, (dTilt * 1.45f).coerceIn(0.28f, 0.72f))
                touchGlow = 1f
                motionHoldSeconds = 0.36f
                lastTiltX = targetX
                lastTiltY = targetY
                tiltRippleCooldown = 0.18f
            }
        }

        if (motionHoldSeconds > 0f) {
            motionHoldSeconds = maxOf(0f, motionHoldSeconds - dt)
        }

        if (isPressed > 0.5f || motionHoldSeconds > 0f) {
            touchGlow = 1f
        } else if (touchGlow > 0.003f) {
            touchGlow *= (1f - min(0.95f, dt * 4.8f))
            if (touchGlow < 0.003f) touchGlow = 0f
        }

        val decay = 1f - min(0.95f, dt * 1.45f)
        if (w0Amp > 0.003f) {
            w0Age += dt
            w0Amp *= decay
            if (w0Amp < 0.003f) w0Amp = 0f
        }
        if (w1Amp > 0.003f) {
            w1Age += dt
            w1Amp *= decay
            if (w1Amp < 0.003f) w1Amp = 0f
        }
        if (w2Amp > 0.003f) {
            w2Age += dt
            w2Amp *= decay
            if (w2Amp < 0.003f) w2Amp = 0f
        }
    }
}

object WaterShaderFactory {
    @Volatile
    var agslFailed: Boolean = false
        private set

    private const val AGSL_GLASS_WATER = """
        uniform float2 uSize;
        uniform float2 uTouch;
        uniform float2 uTilt;
        uniform float uGlow;
        uniform float uSelected;
        uniform float uRadius;
        uniform float uAmbientTime;
        uniform float4 uWave0;
        uniform float4 uWave1;
        uniform float4 uWave2;

        float3 evalRippleSource(float2 uv, float2 origin, float aspect, float age, float amp) {
            float2 d = (uv - origin) * float2(aspect, 1.0);
            float dist = length(d);
            float2 dir = (dist > 0.0005) ? (d / dist) : float2(0.0);

            // Dispersive 3-harmonic gravity + capillary ripple packet
            float waveFront = age * 0.94;
            float ringEnv = exp(-abs(dist - waveFront) * 8.2) * exp(-dist * 1.40);
            float phase1 = (dist * 34.0) - (age * 15.5);
            float phase2 = (dist * 58.0) - (age * 22.0);
            float phase3 = (dist * 86.0) - (age * 29.0);

            // Physical droplet splash rebound at origin
            float reboundEnv = exp(-dist * 9.0) * exp(-age * 3.2);
            float reboundSlope = sin((dist * 24.0) + (age * 16.0)) * reboundEnv * 0.40;

            float slope = (cos(phase1) * ringEnv * 0.64 + cos(phase2) * ringEnv * 0.24 + cos(phase3) * ringEnv * 0.10 + reboundSlope) * amp;
            float crest = (max(0.0, sin(phase1)) * ringEnv + max(0.0, cos(age * 15.5)) * reboundEnv * 0.48) * amp;
            return float3(dir * slope, crest);
        }

        // Evaluates primary ripple PLUS true boundary reflections off all 4 walls
        float3 evalWaveWithBounce(float2 uv, float aspect, float4 w) {
            if (w.w <= 0.002) return float3(0.0);
            float3 sum = evalRippleSource(uv, w.xy, aspect, w.z, w.w);
            float bounceAmp = w.w * 0.58;
            sum += evalRippleSource(uv, float2(-w.x, w.y), aspect, w.z, bounceAmp);
            sum += evalRippleSource(uv, float2(2.0 - w.x, w.y), aspect, w.z, bounceAmp);
            sum += evalRippleSource(uv, float2(w.x, -w.y), aspect, w.z, bounceAmp);
            sum += evalRippleSource(uv, float2(w.x, 2.0 - w.y), aspect, w.z, bounceAmp);
            return sum;
        }

        float2 capillaryCascade(float2 p, float t) {
            float2 s = float2(0.0);
            s += float2(10.7,  4.3)  * cos(dot(p, float2(10.7,  4.3))  - t * 1.12) * 0.0018;
            s += float2(-7.9, 12.8)  * cos(dot(p, float2(-7.9, 12.8))  + t * 0.94) * 0.0014;
            s += float2(18.6, -13.5) * cos(dot(p, float2(18.6, -13.5)) - t * 1.62) * 0.00085;
            s += float2(-24.3,-17.9) * cos(dot(p, float2(-24.3,-17.9)) + t * 2.08) * 0.00052;
            s += float2(33.1, 21.4)  * cos(dot(p, float2(33.1, 21.4))  - t * 2.75) * 0.00028;
            return s;
        }

        float3 snellRefract(float3 I, float3 N, float eta) {
            float ndoti = dot(N, I);
            float k = 1.0 - eta * eta * (1.0 - ndoti * ndoti);
            if (k < 0.0) return reflect(I, N);
            return eta * I - (eta * ndoti + sqrt(k)) * N;
        }

        float causticRibbon(float2 p, float t) {
            float2 q = p * 4.2;
            float a = sin(q.x * 1.9 + t * 0.65 + cos(q.y * 2.2 - t * 0.48));
            float b = cos(q.y * 2.0 - t * 0.55 + sin(q.x * 1.7 + t * 0.42));
            float r = 1.0 - abs(a + b * 0.72) * 0.48;
            float2 q2 = p * 7.6 + float2(1.4, -1.9);
            float c = sin(q2.x * 1.4 - t * 0.72 + cos(q2.y * 1.6 + t * 0.52));
            float d = cos(q2.y * 1.5 + t * 0.58 - sin(q2.x * 1.3 - t * 0.44));
            float r2 = 1.0 - abs(c + d * 0.78) * 0.52;
            return pow(clamp(r, 0.0, 1.0), 5.2) * 0.78 + pow(clamp(r2, 0.0, 1.0), 6.2) * 0.42;
        }

        half4 main(float2 fragCoord) {
            float2 safeSize = max(uSize, float2(1.0));
            float2 uv = fragCoord / safeSize;
            float aspect = safeSize.x / safeSize.y;
            float2 baseP = uv * float2(aspect, 1.0);

            // Combine all 3 wave emitters + boundary wall reflections + motion-gated capillary cascade
            float3 wave = evalWaveWithBounce(uv, aspect, uWave0)
                + evalWaveWithBounce(uv, aspect, uWave1)
                + evalWaveWithBounce(uv, aspect, uWave2);
            float waveActivity = clamp(length(wave.xy) * 1.8 + wave.z * 2.5, 0.0, 1.0);
            float2 micro = capillaryCascade(baseP, uAmbientTime) * (0.04 + 0.96 * waveActivity);

            // Borderless soft meniscus falloff near rounded edges (no hard border stroke)
            float2 halfSize = safeSize * 0.5;
            float2 p = fragCoord - halfSize;
            float r = clamp(uRadius, 1.0, min(halfSize.x, halfSize.y));
            float2 q = abs(p) - (halfSize - float2(r));
            float sdf = length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - r;
            float edgeDist = max(0.0, -sdf);
            float meniscusBand = 1.0 - smoothstep(0.0, 18.0, edgeDist);

            float2 sgn = float2(p.x < 0.0 ? -1.0 : 1.0, p.y < 0.0 ? -1.0 : 1.0);
            float2 cornerVec = max(q, float2(0.0));
            float cornerLen = length(cornerVec);
            float2 boxGrad = (cornerLen > 0.001)
                ? sgn * (cornerVec / cornerLen)
                : ((q.x > q.y) ? float2(sgn.x, 0.0) : float2(0.0, sgn.y));

            float3 N = normalize(float3(
                -(wave.x + micro.x) + boxGrad.x * meniscusBand * 0.22,
                -(wave.y + micro.y) + boxGrad.y * meniscusBand * 0.22,
                1.0
            ));

            float3 V = normalize(float3(
                -uTilt.x * 0.78 - (uv.x - 0.5) * 0.22,
                -uTilt.y * 0.78 - (uv.y - 0.5) * 0.22,
                1.0
            ));

            // Instant 1:1 turquoise light active while moving, touching, dragging, or typing
            float2 dLight = (uTouch - uv) * float2(aspect, 1.0);
            float lightDist = length(dLight);
            float3 L = normalize(float3(dLight.x, dLight.y, 0.30));
            float3 H = normalize(L + V);

            float lightPool = exp(-lightDist * 2.20) * (uGlow * 1.15);
            float lightCore = exp(-lightDist * 5.60) * (uGlow * 0.85);

            // Studio overhead grazing light for constant liquid depth
            float3 Lsky = normalize(float3(uTilt.x * 0.9 + 0.16, -0.52 + uTilt.y * 0.8, 1.05));
            float3 Hsky = normalize(Lsky + V);

            // Real water Schlick Fresnel (F0 = 0.02)
            float NdotV = clamp(dot(N, V), 0.001, 1.0);
            float fresnel = 0.02 + 0.98 * pow(1.0 - NdotV, 5.0);

            // True Snell's Law water refraction (IOR 1.333) + chromatic dispersion
            float3 refrR = snellRefract(-V, N, 0.747);
            float3 refrG = snellRefract(-V, N, 0.750);
            float3 refrB = snellRefract(-V, N, 0.754);
            float depth = 0.18 + wave.z * 0.04;
            float2 bUvR = baseP + (refrR.xy / max(abs(refrR.z), 0.25)) * depth;
            float2 bUvG = baseP + (refrG.xy / max(abs(refrG.z), 0.25)) * depth;
            float2 bUvB = baseP + (refrB.xy / max(abs(refrB.z), 0.25)) * depth;

            float cR = causticRibbon(bUvR, uAmbientTime * 0.35);
            float cG = causticRibbon(bUvG, uAmbientTime * 0.35);
            float cB = causticRibbon(bUvB, uAmbientTime * 0.35);
            float3 caustics = float3(cR * 0.18, cG * 0.96, cB * 0.92);

            // Crystal-clear Beer-Lambert transmission for vivid optical clarity
            float3 absorption = exp(-(depth * 2.8 + uv.y * 0.32) * float3(0.68, 0.10, 0.13));

            // Reflected environment sheen
            float3 R = reflect(-V, N);
            float skyBand = smoothstep(-0.15, 0.75, -R.y);
            float horizonBand = exp(-abs(R.y + 0.24 - uTilt.y * 0.28) * 7.8);
            float3 envReflect = mix(
                float3(0.012, 0.052, 0.064),
                float3(0.062, 0.38, 0.39),
                skyBand
            ) + float3(0.00, 0.94, 0.83) * horizonBand * (0.14 + lightPool * 0.72);

            // Multi-lobe wet specular glints active during user motion
            float ndoth = clamp(dot(N, H), 0.0001, 1.0);
            float specPinpoint = pow(ndoth, 280.0) * (uGlow * 2.15);
            float specCrisp = pow(ndoth, 76.0) * (uGlow * 0.86);
            float specPointerSoft = pow(ndoth, 16.0) * (uGlow * 0.48);
            float specSky = pow(clamp(dot(N, Hsky), 0.0001, 1.0), 115.0) * (0.14 + wave.z * 0.26 + meniscusBand * 0.14);

            // Crystal-clear spring turquoise volume
            float3 deepTop = float3(0.022, 0.105, 0.126);
            float3 deepBottom = float3(0.009, 0.042, 0.054);
            float3 baseWater = mix(deepTop, deepBottom, smoothstep(0.0, 1.0, uv.y)) * absorption;

            float3 turquoiseCol = float3(0.00, 0.94, 0.83);
            float3 aquaSpecCol  = float3(0.84, 1.00, 0.98);

            float selectLift = uSelected * 0.14;
            float3 refracted = baseWater
                + caustics * (0.10 + lightPool * 0.34 + wave.z * 0.22) * absorption
                + turquoiseCol * (lightPool * 0.36 + lightCore * 0.28 + wave.z * 0.30 + selectLift) * absorption;

            float3 finalCol = mix(refracted, envReflect, clamp(fresnel * 1.48, 0.04, 0.86))
                + aquaSpecCol * (specPinpoint + specCrisp * 0.58 + specSky + wave.z * 0.24)
                + turquoiseCol * specPointerSoft;

            // Smooth borderless edge alpha fade (zero harsh card outline)
            float edgeFeather = smoothstep(0.0, 3.0, edgeDist);
            float alpha = clamp(
                (0.76 + fresnel * 0.14 + lightPool * 0.12 + selectLift * 0.14) * mix(0.86, 1.0, edgeFeather),
                0.68,
                0.95
            );
            return half4(half3(finalCol * alpha), half(alpha));
        }
    """

    fun createRuntimeShader(): RuntimeShader? {
        if (agslFailed || Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return null
        return runCatching {
            RuntimeShader(AGSL_GLASS_WATER)
        }.getOrElse {
            agslFailed = true
            null
        }
    }
}
