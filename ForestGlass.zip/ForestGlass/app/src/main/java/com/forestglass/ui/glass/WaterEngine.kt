package com.forestglass.ui.glass

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Lightweight 2D shallow-water wave simulation:
 * Automatically idles at 0% CPU when ripples and touch glow settle.
 */
@Stable
class WaterState(
    private val cols: Int = 36,
    private val rows: Int = 20
) {
    private val size = cols * rows
    private val hCurr = FloatArray(size)
    private val hPrev = FloatArray(size)
    private val hNext = FloatArray(size)
    private val pixels = IntArray(size)

    val waveBitmap: Bitmap = Bitmap.createBitmap(cols, rows, Bitmap.Config.ARGB_8888)

    var touchNormX by mutableFloatStateOf(0.5f)
    var touchNormY by mutableFloatStateOf(0.5f)
    var touchGlow by mutableFloatStateOf(0f)
    var isPressed by mutableFloatStateOf(0f)
    var energy by mutableFloatStateOf(0f)
        private set

    fun injectTouch(normX: Float, normY: Float, pressed: Boolean) {
        val nx = normX.coerceIn(0.02f, 0.98f)
        val ny = normY.coerceIn(0.02f, 0.98f)
        touchNormX = nx
        touchNormY = ny
        isPressed = if (pressed) 1f else 0f
        if (pressed) {
            touchGlow = max(touchGlow, 0.95f)
            val gx = (nx * (cols - 1)).toInt().coerceIn(1, cols - 2)
            val gy = (ny * (rows - 1)).toInt().coerceIn(1, rows - 2)
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val falloff = if (dx == 0 && dy == 0) 0.95f else 0.45f
                    val idx = (gy + dy) * cols + (gx + dx)
                    hCurr[idx] = (hCurr[idx] + falloff).coerceIn(-1.5f, 1.5f)
                }
            }
            energy = 1f
        }
    }

    fun step(dtSeconds: Float, tiltX: Float, tiltY: Float) {
        val dt = dtSeconds.coerceIn(0.001f, 0.033f)

        if (isPressed > 0.5f) {
            touchGlow = min(1f, touchGlow + dt * 5f)
        } else if (touchGlow > 0.002f) {
            touchGlow *= (1f - min(0.95f, dt * 3.8f))
            if (touchGlow < 0.002f) touchGlow = 0f
        }

        val tiltMag = abs(tiltX) + abs(tiltY)
        if (tiltMag > 0.14f && energy < 0.25f) {
            val ix = ((0.5f + tiltX * 0.35f) * (cols - 1)).toInt().coerceIn(1, cols - 2)
            val iy = ((0.5f + tiltY * 0.35f) * (rows - 1)).toInt().coerceIn(1, rows - 2)
            hCurr[iy * cols + ix] += tiltMag * 0.12f
            energy = max(energy, 0.2f)
        }

        if (energy <= 0.001f && touchGlow <= 0.002f) return

        val damping = 0.935f
        var maxEnergy = 0f
        for (y in 1 until rows - 1) {
            val rowOff = y * cols
            for (x in 1 until cols - 1) {
                val i = rowOff + x
                val avg = (hCurr[i - 1] + hCurr[i + 1] + hCurr[i - cols] + hCurr[i + cols]) * 0.5f
                val v = (avg - hPrev[i]) * damping
                val clamped = v.coerceIn(-1.4f, 1.4f)
                hNext[i] = clamped
                val a = abs(clamped)
                if (a > maxEnergy) maxEnergy = a
            }
        }

        for (i in 0 until size) {
            hPrev[i] = hCurr[i]
            hCurr[i] = hNext[i]
        }
        energy = maxEnergy

        for (y in 0 until rows) {
            val rowOff = y * cols
            for (x in 0 until cols) {
                val i = rowOff + x
                val l = if (x > 0) hCurr[i - 1] else hCurr[i]
                val r = if (x < cols - 1) hCurr[i + 1] else hCurr[i]
                val u = if (y > 0) hCurr[i - cols] else hCurr[i]
                val d = if (y < rows - 1) hCurr[i + cols] else hCurr[i]

                val nx = ((r - l) * 0.5f + 0.5f).coerceIn(0f, 1f)
                val ny = ((d - u) * 0.5f + 0.5f).coerceIn(0f, 1f)
                val h = (hCurr[i] * 0.5f + 0.5f).coerceIn(0f, 1f)

                val ir = (nx * 255f).toInt()
                val ig = (ny * 255f).toInt()
                val ib = (h * 255f).toInt()
                pixels[i] = (0xFF shl 24) or (ir shl 16) or (ig shl 8) or ib
            }
        }
        waveBitmap.setPixels(pixels, 0, cols, 0, 0, cols, rows)
    }
}

object WaterShaderFactory {
    @Volatile
    var agslFailed: Boolean = false
        private set

    private const val AGSL_GLASS_WATER = """
        uniform float2 uSize;
        uniform float2 uWaveSize;
        uniform float2 uTouch;
        uniform float2 uTilt;
        uniform float uGlow;
        uniform float uSelected;
        uniform float uRadius;
        uniform shader uWave;

        half4 main(float2 fragCoord) {
            float2 safeSize = max(uSize, float2(1.0));
            float2 uv = fragCoord / safeSize;
            float2 wCoord = uv * uWaveSize;
            half4 wSample = uWave.eval(wCoord);

            float2 waveN = (float2(wSample.rg) - 0.5) * 2.0;
            float height = (float(wSample.b) - 0.5) * 2.0;

            float2 halfSize = safeSize * 0.5;
            float2 p = fragCoord - halfSize;
            float r = clamp(uRadius, 1.0, min(halfSize.x, halfSize.y));
            float2 q = abs(p) - (halfSize - float2(r));
            float sdf = length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - r;
            float edgeDist = max(0.0, -sdf);
            float bevelWidth = max(r * 1.15, 20.0);
            float bevelBand = clamp(edgeDist / bevelWidth, 0.0, 1.0);
            float rimSlope = 1.0 - smoothstep(0.0, 1.0, bevelBand);

            float2 sgn = float2(p.x < 0.0 ? -1.0 : 1.0, p.y < 0.0 ? -1.0 : 1.0);
            float2 cornerVec = max(q, float2(0.0));
            float cornerLen = length(cornerVec);
            float2 boxGrad = (cornerLen > 0.001)
                ? sgn * (cornerVec / cornerLen)
                : ((q.x > q.y) ? float2(sgn.x, 0.0) : float2(0.0, sgn.y));

            float3 N = normalize(float3(
                waveN.x * 0.65 + boxGrad.x * rimSlope * 0.72,
                waveN.y * 0.65 + boxGrad.y * rimSlope * 0.72,
                1.0
            ));

            float3 V = normalize(float3(
                -uTilt.x * 0.85 - (uv.x - 0.5) * 0.28,
                -uTilt.y * 0.85 - (uv.y - 0.5) * 0.28,
                1.0
            ));

            float NdotV = clamp(dot(N, V), 0.0, 1.0);
            float fresnelBase = clamp(1.0 - NdotV, 0.0001, 1.0);
            float F0 = 0.05;
            float fresnel = F0 + (1.0 - F0) * pow(fresnelBase, 4.0);
            float tiltGrazing = clamp(length(uTilt) * 0.55, 0.0, 0.55);
            float edgeFresnel = fresnel * (0.45 + rimSlope * 1.45 + tiltGrazing);

            float3 R = reflect(-V, N);
            float skyBand = smoothstep(-0.15, 0.65, -R.y) * 0.35 + smoothstep(0.55, 0.96, R.z) * 0.22;
            float stripDist = clamp(1.0 - abs(R.y + 0.38 - uTilt.y * 0.35), 0.0001, 1.0);
            float studioStrip = pow(stripDist, 10.0) * 0.55;
            float3 envReflect = float3(0.18, 0.82, 0.68) * skyBand + float3(0.84, 1.00, 0.96) * studioStrip;

            float3 L1 = normalize(float3(uTilt.x * 1.20 + 0.22, -0.58 + uTilt.y * 0.95, 1.05));
            float3 H1 = normalize(L1 + V);
            float specBase = clamp(dot(N, H1), 0.0001, 1.0);

            float edgeAmp = 1.0 + rimSlope * 2.15;
            float specSharp = pow(specBase, 56.0) * edgeAmp * 0.68;
            float specBroad = pow(specBase, 11.0) * (0.16 + rimSlope * 0.24);

            float3 Ltouch = normalize(float3((uTouch.x - uv.x) * 2.2, (uTouch.y - uv.y) * 2.2, 0.75));
            float3 Htouch = normalize(Ltouch + V);
            float touchSpecBase = clamp(dot(N, Htouch), 0.0001, 1.0);
            float specTouch = pow(touchSpecBase, 30.0) * uGlow * (0.55 + rimSlope * 0.85);

            float2 lightPos = float2(0.5 + uTilt.x * 0.28, 0.16 + uTilt.y * 0.22);
            float ambient = exp(-distance(uv, lightPos) * 2.3) * 0.11;

            float2 dTouch = (uv - uTouch) * float2(safeSize.x / safeSize.y, 1.0);
            float touchLight = exp(-length(dTouch) * 3.5) * uGlow * 0.46;

            float waveHighlight = clamp(waveN.x * 0.7 + waveN.y * 0.7 + height * 0.4, 0.0, 1.0);
            float caustic = waveHighlight * (0.12 + uGlow * 0.22);
            float selectTint = uSelected * 0.16;

            float3 deepTop = float3(0.015, 0.044, 0.050);
            float3 deepBottom = float3(0.007, 0.019, 0.023);
            float3 baseCol = mix(deepTop, deepBottom, smoothstep(0.0, 1.0, uv.y));

            float3 mintCol = float3(0.00, 0.98, 0.75);
            float3 specularCol = float3(0.84, 1.00, 0.96);

            float3 finalCol = baseCol
                + mintCol * (ambient + touchLight + caustic + selectTint) * 0.45
                + envReflect * edgeFresnel
                + specularCol * (specSharp + specBroad + specTouch);

            float alpha = clamp(
                0.80 + edgeFresnel * 0.14 + touchLight * 0.15 + selectTint * 0.18,
                0.80,
                0.97
            );
            return half4(half3(finalCol * alpha), half(alpha));
        }
    """

    fun createRuntimeShader(waveBitmap: Bitmap): RuntimeShader? {
        if (agslFailed || Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return null
        return runCatching {
            val shader = RuntimeShader(AGSL_GLASS_WATER)
            val bmpShader = BitmapShader(waveBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            shader.setInputBuffer("uWave", bmpShader)
            shader.setFloatUniform("uWaveSize", waveBitmap.width.toFloat(), waveBitmap.height.toFloat())
            shader
        }.getOrElse {
            agslFailed = true
            null
        }
    }
}
