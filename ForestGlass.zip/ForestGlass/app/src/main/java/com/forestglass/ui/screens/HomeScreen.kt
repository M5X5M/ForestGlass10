package com.forestglass.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.forestglass.data.Lesson
import com.forestglass.data.LessonRepository
import com.forestglass.data.PhysicsIndex
import com.forestglass.data.ReviewSuggestion
import com.forestglass.data.Subject
import com.forestglass.ui.glass.GlassCard
import com.forestglass.ui.glass.GlassTier
import com.forestglass.ui.glass.LocalWaterPulse
import com.forestglass.ui.theme.FIcon
import com.forestglass.ui.theme.ForestIcon
import com.forestglass.ui.theme.ForestTokens
import com.forestglass.ui.theme.fluidRise

@Composable
fun HomeScreen(
    suggestion: ReviewSuggestion,
    onOpenSearch: () -> Unit,
    onOpenLesson: (Lesson) -> Unit,
    onSelectSubject: (Subject) -> Unit,
    bottomPadding: PaddingValues,
    modifier: Modifier = Modifier
) {
    val quickLaws = remember { PhysicsIndex.fallbackLaws.take(3) }
    val waterPulse = LocalWaterPulse.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = ForestTokens.ScreenPadding),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 180.dp),
            modifier = Modifier
                .widthIn(max = 960.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(
                top = 18.dp,
                bottom = bottomPadding.calculateBottomPadding() + 20.dp
            ),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(modifier = Modifier.fluidRise(0).padding(bottom = 2.dp)) {
                    Text(
                        text = "مرحبا بك",
                        color = ForestTokens.MintGlow,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = "ماذا ندرس اليوم؟",
                        color = ForestTokens.TextPrimary,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                GlassCard(
                    cornerRadius = 22.dp,
                    onClick = {
                        waterPulse.emit(0.5f, 0.18f, 0.72f)
                        onOpenSearch()
                    },
                    modifier = Modifier.fillMaxWidth().fluidRise(1)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 15.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .background(ForestTokens.MintBadge, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            ForestIcon(
                                icon = FIcon.SEARCH,
                                size = 16.dp,
                                tint = ForestTokens.MintGlow
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = "ابحث عن أي قانون أو معادلة...",
                            color = ForestTokens.TextSecondary,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                GlassCard(
                    cornerRadius = ForestTokens.CardRadius,
                    selected = true,
                    onClick = {
                        waterPulse.emit(0.5f, 0.30f, 0.85f)
                        onOpenLesson(suggestion.lesson)
                    },
                    modifier = Modifier.fillMaxWidth().fluidRise(2)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "المراجعة المقترحة",
                                color = ForestTokens.MintGlow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = suggestion.lesson.title,
                                color = ForestTokens.TextPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(3.dp))
                            Text(
                                text = "${suggestion.lesson.subject.titleAr} · ${suggestion.lesson.teacher} · ${suggestion.statusLabel}",
                                color = ForestTokens.TextSecondary,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(ForestTokens.MintSoft, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            ForestIcon(
                                icon = FIcon.PLAY,
                                size = 19.dp,
                                tint = ForestTokens.MintGlow
                            )
                        }
                    }
                }
            }

            items(Subject.entries, key = { it.name }) { subject ->
                SubjectCard(
                    subject = subject,
                    lessonCount = LessonRepository.bySubject(subject).size,
                    onClick = {
                        waterPulse.emit(0.5f, 0.52f, 0.78f)
                        onSelectSubject(subject)
                    },
                    modifier = Modifier.animateItem().fluidRise(3 + subject.ordinal)
                )
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "قوانين سريعة للمراجعة",
                    color = ForestTokens.TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fluidRise(7).padding(top = 4.dp)
                )
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    modifier = Modifier.fillMaxWidth().fluidRise(8),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    quickLaws.forEachIndexed { idx, law ->
                        GlassCard(
                            cornerRadius = 20.dp,
                            tier = GlassTier.Lite,
                            onClick = {
                                waterPulse.emit(0.25f + idx * 0.25f, 0.78f, 0.72f)
                                val target = law.lessonId?.let(LessonRepository::findById)
                                if (target != null) onOpenLesson(target) else onOpenSearch()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Text(
                                    text = law.title,
                                    color = ForestTokens.TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(Modifier.height(5.dp))
                                Text(
                                    text = law.formula,
                                    color = ForestTokens.MintGlow,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SubjectCard(
    subject: Subject,
    lessonCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val icon = when (subject) {
        Subject.PHYSICS -> FIcon.PHYSICS
        Subject.CHEMISTRY -> FIcon.CHEMISTRY
        Subject.BIOLOGY -> FIcon.BIOLOGY
        Subject.MATH -> FIcon.MATH
    }
    GlassCard(
        cornerRadius = ForestTokens.CardRadius,
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(142.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(ForestTokens.MintBadge, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    ForestIcon(icon = icon, size = 22.dp, tint = ForestTokens.MintGlow)
                }

                Text(
                    text = "$lessonCount دروس",
                    color = ForestTokens.MintGlow,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .background(ForestTokens.MintBadge, RoundedCornerShape(10.dp))
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                )
            }

            Column {
                Text(
                    text = subject.titleAr,
                    color = ForestTokens.TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subject.subtitleAr,
                    color = ForestTokens.TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
