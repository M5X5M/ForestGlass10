package com.forestglass.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object ForestTokens {
    val BlackOled = Color(0xFF000000)

    // Deep Glass Tints
    val GlassBase = Color(0xFF02090C)
    val GlassDeepCore = Color(0xFF041318)
    val GlassSurfaceLite = Color(0xE6041318)
    val GlassSurfaceLiteGradient: Brush = Brush.verticalGradient(
        colors = listOf(
            Color(0xE6061C22),
            Color(0xEB041318),
            Color(0xF201080B)
        )
    )
    val GlassBorder = Color(0xFF0A1A1E)
    val GlassBorderFocused = Color(0x9900FFC2)

    // Fresnel & Specular Highlights
    val GlassFresnelTint = Color(0xFF14B89B)
    val GlassSpecular = Color(0xFFD4FFF5)

    // Vibrant Neon Mint Accents
    val MintGlow = Color(0xFF00FFC2)
    val MintSoft = Color(0x2400FFC2)
    val MintPressed = Color(0x3D00FFC2)
    val MintBadge = Color(0x1C00FFC2)

    val TextPrimary = Color(0xFFEDF7F4)
    val TextSecondary = Color(0xFF8EABA5)
    val TextMuted = Color(0xFF536E69)
    val Danger = Color(0xFFE85D6F)
    val Warning = Color(0xFFEAB658)

    val CardRadius = 24.dp
    val PillRadius = 20.dp
    val ButtonRadius = 18.dp
    val ScreenPadding = 18.dp
}
