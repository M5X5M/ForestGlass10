package com.forestglass.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object ForestTokens {
    val BlackOled = Color(0xFF000000)

    // Deep Borderless Liquid Glass Tints
    val GlassBase = Color(0xFF01080B)
    val GlassDeepCore = Color(0xFF031419)
    val GlassSurfaceLite = Color(0xCC03141A)
    val GlassSurfaceLiteGradient: Brush = Brush.verticalGradient(
        colors = listOf(
            Color(0xD6052128),
            Color(0xCC03141A),
            Color(0xDE010A0E)
        )
    )
    val GlassBorder = Color.Transparent
    val GlassBorderFocused = Color.Transparent

    // Soft internal edge washes (borderless, zero hard stroke)
    val GlassRimBrush: Brush = Brush.linearGradient(
        colors = listOf(Color.Transparent, Color.Transparent)
    )
    val GlassRimFocusedBrush: Brush = Brush.linearGradient(
        colors = listOf(Color.Transparent, Color.Transparent)
    )

    // Ambient Deep Turquoise Underwater Glows
    val AmbientTealTop = Color(0x4206464D)
    val AmbientMintCenter = Color(0x2800F0D4)

    // Fresnel & Specular Highlights
    val GlassFresnelTint = Color(0xFF0ED2B8)
    val GlassSpecular = Color(0xFFC8FFF8)

    // Luxurious Turquoise Accents
    val MintGlow = Color(0xFF00F0D4)
    val MintSoft = Color(0x2600F0D4)
    val MintPressed = Color(0x4500F0D4)
    val MintBadge = Color(0x2000F0D4)

    val TextPrimary = Color(0xFFEDF7F4)
    val TextSecondary = Color(0xFF96B8B2)
    val TextMuted = Color(0xFF5D8079)
    val Danger = Color(0xFFE85D6F)
    val Warning = Color(0xFFEAB658)

    val CardRadius = 28.dp
    val PillRadius = 22.dp
    val ButtonRadius = 20.dp
    val ScreenPadding = 18.dp
}
