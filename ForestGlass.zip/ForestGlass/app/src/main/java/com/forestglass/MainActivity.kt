package com.forestglass

import android.content.pm.ActivityInfo
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.forestglass.data.LessonRepository
import com.forestglass.data.PhysicsIndex
import com.forestglass.data.StudyTracker
import com.forestglass.data.Subject
import com.forestglass.sensor.TiltSensor
import com.forestglass.sensor.TiltState
import com.forestglass.ui.AppRoute
import com.forestglass.ui.GlassBottomBar
import com.forestglass.ui.MainTab
import com.forestglass.ui.glass.LocalTiltState
import com.forestglass.ui.glass.LocalWaterPulse
import com.forestglass.ui.glass.WaterPulseBus
import com.forestglass.ui.screens.AccountScreen
import com.forestglass.ui.screens.DecoyScreen
import com.forestglass.ui.screens.FocusScreen
import com.forestglass.ui.screens.HomeScreen
import com.forestglass.ui.screens.LessonScreen
import com.forestglass.ui.screens.PinStore
import com.forestglass.ui.screens.ProgressScreen
import com.forestglass.ui.screens.SearchScreen
import com.forestglass.ui.theme.ForestMotion
import com.forestglass.ui.theme.ForestTokens
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var activeWaterPulse: WaterPulseBus? = null

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action == android.view.KeyEvent.ACTION_DOWN) {
            val code = event.keyCode
            val kx = ((code * 37) % 76 + 12) / 100f
            val ky = ((code * 53) % 58 + 18) / 100f
            activeWaterPulse?.emit(kx, ky, 0.72f)
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )

        val tracker = StudyTracker(applicationContext)
        val physicsLaws = PhysicsIndex.loadFromAssets(applicationContext)

        setContent {
            val scope = rememberCoroutineScope()
            val lifecycleOwner = LocalLifecycleOwner.current

            var tiltState by remember { mutableStateOf(TiltState()) }
            val tiltSensor = remember {
                TiltSensor(applicationContext) { x, y ->
                    tiltState = TiltState(x, y)
                }
            }

            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    when (event) {
                        Lifecycle.Event.ON_START -> tiltSensor.start()
                        Lifecycle.Event.ON_STOP -> tiltSensor.stop()
                        else -> Unit
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                    tiltSensor.stop()
                }
            }

            val stats by tracker.statsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
            val statsMap = remember(stats) { stats.associateBy { it.lessonId } }
            val suggestion = remember(stats) { tracker.pickSuggestedReview(stats) }

            var route by rememberSaveable { mutableStateOf(AppRoute.HOME) }
            var selectedSubject by rememberSaveable { mutableStateOf(Subject.PHYSICS) }
            var selectedLessonId by rememberSaveable {
                mutableStateOf(LessonRepository.allLessons.first().id)
            }
            var isVideoFullscreen by rememberSaveable { mutableStateOf(false) }
            var savedPin by remember { mutableStateOf(PinStore.load(applicationContext)) }

            val currentLesson = remember(selectedLessonId, selectedSubject) {
                LessonRepository.findById(selectedLessonId)
                    ?: LessonRepository.bySubject(selectedSubject).firstOrNull()
                    ?: LessonRepository.allLessons.first()
            }

            LaunchedEffect(isVideoFullscreen, route) {
                val activeFullscreen = (isVideoFullscreen && route == AppRoute.LESSONS) ||
                    route == AppRoute.FOCUS
                applyImmersiveMode(
                    hideBars = activeFullscreen,
                    lockLandscape = isVideoFullscreen && route == AppRoute.LESSONS
                )
            }

            LaunchedEffect(route, isVideoFullscreen) {
                if (route == AppRoute.FOCUS || (isVideoFullscreen && route == AppRoute.LESSONS)) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            val showBottomBar = route in setOf(
                AppRoute.HOME,
                AppRoute.LESSONS,
                AppRoute.PROGRESS,
                AppRoute.ACCOUNT
            ) && !isVideoFullscreen

            val tabOrder = remember {
                mapOf(
                    AppRoute.HOME to 0,
                    AppRoute.LESSONS to 1,
                    AppRoute.PROGRESS to 2,
                    AppRoute.ACCOUNT to 3
                )
            }

            val waterPulse = remember { WaterPulseBus() }
            DisposableEffect(waterPulse) {
                activeWaterPulse = waterPulse
                onDispose {
                    if (activeWaterPulse === waterPulse) activeWaterPulse = null
                }
            }

            CompositionLocalProvider(
                LocalLayoutDirection provides LayoutDirection.Rtl,
                LocalTiltState provides tiltState,
                LocalWaterPulse provides waterPulse
            ) {
                Scaffold(
                    containerColor = ForestTokens.BlackOled,
                    bottomBar = {
                        if (showBottomBar) {
                            GlassBottomBar(
                                currentRoute = route,
                                onSelectTab = { tab: MainTab ->
                                    waterPulse.emit(0.2f + tab.ordinal * 0.2f, 0.90f, 0.80f)
                                    isVideoFullscreen = false
                                    route = tab.route
                                }
                            )
                        }
                    }
                ) { innerPadding: PaddingValues ->
                    val effectiveBottom = if (showBottomBar) innerPadding else PaddingValues(0.dp)
                    var fingerNorm by remember { mutableStateOf(Offset(0.5f, 0.3f)) }
                    var fingerActive by remember { mutableStateOf(false) }
                    var lastMotionSeq by remember { mutableStateOf(0) }
                    val pulseProgress = remember { Animatable(0f) }

                    LaunchedEffect(lastMotionSeq) {
                        if (lastMotionSeq > 0) {
                            kotlinx.coroutines.delay(380L)
                            fingerActive = false
                        }
                    }

                    LaunchedEffect(waterPulse.sequence) {
                        if (waterPulse.sequence > 0) {
                            fingerNorm = Offset(waterPulse.normX, waterPulse.normY)
                            pulseProgress.snapTo(0.01f)
                            pulseProgress.animateTo(
                                targetValue = 1f,
                                animationSpec = tween(durationMillis = 780, easing = ForestMotion.SmoothEasing)
                            )
                            pulseProgress.snapTo(0f)
                        }
                    }

                    val fingerGlowAlpha by animateFloatAsState(
                        targetValue = when {
                            fingerActive -> 0.36f
                            pulseProgress.value > 0f -> 0.30f * (1f - pulseProgress.value)
                            else -> 0f
                        },
                        animationSpec = tween(durationMillis = if (fingerActive) 35 else 220),
                        label = "ambientFingerAlpha"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ForestTokens.BlackOled)
                            .pointerInput(Unit) {
                                awaitPointerEventScope {
                                    while (true) {
                                        val event = awaitPointerEvent(PointerEventPass.Initial)
                                        val change = event.changes.firstOrNull() ?: continue
                                        val w = size.width.coerceAtLeast(1).toFloat()
                                        val h = size.height.coerceAtLeast(1).toFloat()
                                        when (event.type) {
                                            PointerEventType.Press -> {
                                                fingerNorm = Offset(
                                                    (change.position.x / w).coerceIn(0f, 1f),
                                                    (change.position.y / h).coerceIn(0f, 1f)
                                                )
                                                fingerActive = true
                                            }
                                            PointerEventType.Move -> {
                                                fingerNorm = Offset(
                                                    (change.position.x / w).coerceIn(0f, 1f),
                                                    (change.position.y / h).coerceIn(0f, 1f)
                                                )
                                                fingerActive = true
                                                if (!change.pressed) lastMotionSeq++
                                            }
                                            PointerEventType.Release -> lastMotionSeq++
                                            else -> Unit
                                        }
                                    }
                                }
                            }
                            .drawBehind {
                                val w = size.width
                                val h = size.height
                                val maxDim = maxOf(w, h)
                                drawRect(
                                    brush = Brush.radialGradient(
                                        colors = listOf(
                                            ForestTokens.AmbientTealTop,
                                            Color.Transparent
                                        ),
                                        center = Offset(w * (0.28f + tiltState.x * 0.09f), h * (0.14f + tiltState.y * 0.07f)),
                                        radius = maxDim * 0.68f
                                    )
                                )
                                drawRect(
                                    brush = Brush.radialGradient(
                                        colors = listOf(
                                            ForestTokens.AmbientMintCenter,
                                            Color.Transparent
                                        ),
                                        center = Offset(w * (0.76f - tiltState.x * 0.09f), h * (0.78f - tiltState.y * 0.07f)),
                                        radius = maxDim * 0.58f
                                    )
                                )
                                if (fingerGlowAlpha > 0.002f) {
                                    drawRect(
                                        brush = Brush.radialGradient(
                                            colors = listOf(
                                                ForestTokens.MintGlow.copy(alpha = fingerGlowAlpha),
                                                ForestTokens.GlassFresnelTint.copy(alpha = fingerGlowAlpha * 0.48f),
                                                Color.Transparent
                                            ),
                                            center = Offset(w * fingerNorm.x, h * fingerNorm.y),
                                            radius = maxDim * 0.46f
                                        )
                                    )
                                }
                                val p = pulseProgress.value
                                if (p > 0f && p < 1f) {
                                    val origin = Offset(w * waterPulse.normX, h * waterPulse.normY)
                                    val fade = (1f - p) * waterPulse.strength
                                    drawCircle(
                                        color = ForestTokens.MintGlow.copy(alpha = 0.24f * fade),
                                        radius = maxDim * (0.04f + p * 0.36f),
                                        center = origin,
                                        style = Stroke(width = (3.6f * (1f - p * 0.5f)).dp.toPx())
                                    )
                                    drawCircle(
                                        color = ForestTokens.GlassSpecular.copy(alpha = 0.14f * fade),
                                        radius = maxDim * (0.015f + p * 0.22f),
                                        center = origin,
                                        style = Stroke(width = 1.6.dp.toPx())
                                    )
                                }
                            }
                    ) {
                        AnimatedContent(
                            targetState = route,
                            transitionSpec = {
                                val fromTab = tabOrder[initialState]
                                val toTab = tabOrder[targetState]
                                when {
                                    fromTab != null && toTab != null ->
                                        ForestMotion.tabTransition(toTab - fromTab)
                                    targetState == AppRoute.SEARCH || targetState == AppRoute.FOCUS || targetState == AppRoute.DECOY ->
                                        ForestMotion.depthEnterTransition
                                    else ->
                                        ForestMotion.depthExitTransition
                                }
                            },
                            label = "mainRoute"
                        ) { targetRoute ->
                            when (targetRoute) {
                                AppRoute.HOME -> HomeScreen(
                                    suggestion = suggestion,
                                    onOpenSearch = { route = AppRoute.SEARCH },
                                    onOpenLesson = { lesson ->
                                        selectedSubject = lesson.subject
                                        selectedLessonId = lesson.id
                                        route = AppRoute.LESSONS
                                    },
                                    onSelectSubject = { subject ->
                                        selectedSubject = subject
                                        LessonRepository.bySubject(subject).firstOrNull()?.let {
                                            selectedLessonId = it.id
                                        }
                                        route = AppRoute.LESSONS
                                    },
                                    bottomPadding = effectiveBottom
                                )

                                AppRoute.LESSONS -> LessonScreen(
                                    subject = selectedSubject,
                                    currentLesson = currentLesson,
                                    statsMap = statsMap,
                                    isFullscreen = isVideoFullscreen,
                                    onFullscreenChange = { isVideoFullscreen = it },
                                    onSelectSubject = { subject ->
                                        selectedSubject = subject
                                        LessonRepository.bySubject(subject).firstOrNull()?.let {
                                            selectedLessonId = it.id
                                        }
                                    },
                                    onSelectLesson = { lesson ->
                                        selectedLessonId = lesson.id
                                    },
                                    onStartFocus = {
                                        isVideoFullscreen = false
                                        route = AppRoute.FOCUS
                                    },
                                    onTickStudySecond = { lesson ->
                                        scope.launch {
                                            tracker.recordStudyProgress(lesson, addedSeconds = 15L)
                                        }
                                    },
                                    onMarkCompleted = { lesson ->
                                        scope.launch {
                                            tracker.recordStudyProgress(
                                                lesson,
                                                addedSeconds = 60L,
                                                markCompleted = true
                                            )
                                        }
                                    },
                                    onBack = {
                                        isVideoFullscreen = false
                                        route = AppRoute.HOME
                                    },
                                    bottomPadding = effectiveBottom
                                )

                                AppRoute.PROGRESS -> ProgressScreen(
                                    stats = stats,
                                    suggestion = suggestion,
                                    onOpenLesson = { lesson ->
                                        selectedSubject = lesson.subject
                                        selectedLessonId = lesson.id
                                        route = AppRoute.LESSONS
                                    },
                                    bottomPadding = effectiveBottom
                                )

                                AppRoute.ACCOUNT -> AccountScreen(
                                    currentPin = savedPin,
                                    onUpdatePin = { newPin ->
                                        PinStore.save(applicationContext, newPin)
                                        savedPin = newPin
                                    },
                                    onResetProgress = {
                                        scope.launch { tracker.resetAll() }
                                    },
                                    bottomPadding = effectiveBottom
                                )

                                AppRoute.SEARCH -> SearchScreen(
                                    laws = physicsLaws,
                                    onOpenLessonById = { lessonId ->
                                        LessonRepository.findById(lessonId)?.let { lesson ->
                                            selectedSubject = lesson.subject
                                            selectedLessonId = lesson.id
                                            route = AppRoute.LESSONS
                                        }
                                    },
                                    onBack = { route = AppRoute.HOME }
                                )

                                AppRoute.FOCUS -> FocusScreen(
                                    lesson = currentLesson,
                                    savedPin = savedPin,
                                    onExitFocus = { route = AppRoute.LESSONS },
                                    onOpenDecoy = { route = AppRoute.DECOY }
                                )

                                AppRoute.DECOY -> DecoyScreen(
                                    secretPin = savedPin,
                                    onUnlockSuccess = { route = AppRoute.HOME }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun applyImmersiveMode(hideBars: Boolean, lockLandscape: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        val isCompactPhone = resources.configuration.smallestScreenWidthDp < 600
        if (hideBars) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
            if (lockLandscape && isCompactPhone) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
}
