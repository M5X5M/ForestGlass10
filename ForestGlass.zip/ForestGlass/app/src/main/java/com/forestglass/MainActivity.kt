package com.forestglass

import android.app.ActivityManager
import android.content.pm.ActivityInfo
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.forestglass.data.LessonRepository
import com.forestglass.data.PhysicsIndex
import com.forestglass.data.StudyTracker
import com.forestglass.data.Subject
import com.forestglass.sensor.TiltSensor
import com.forestglass.sensor.TiltState
import com.forestglass.ui.AppRoute
import com.forestglass.ui.GlassBottomBar
import com.forestglass.ui.MainTab
import com.forestglass.ui.glass.LocalTiltState
import com.forestglass.ui.screens.AccountScreen
import com.forestglass.ui.screens.DecoyScreen
import com.forestglass.ui.screens.FocusScreen
import com.forestglass.ui.screens.HomeScreen
import com.forestglass.ui.screens.LessonScreen
import com.forestglass.ui.screens.PinStore
import com.forestglass.ui.screens.ProgressScreen
import com.forestglass.ui.screens.SearchScreen
import com.forestglass.ui.theme.ForestMotion
import com.forestglass.ui.theme.ForestTokens
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )

        val tracker = StudyTracker(applicationContext)
        val physicsLaws = PhysicsIndex.loadFromAssets(applicationContext)

        setContent {
            val scope = rememberCoroutineScope()
            val lifecycleOwner = LocalLifecycleOwner.current

            var tiltState by remember { mutableStateOf(TiltState()) }
            val tiltSensor = remember {
                TiltSensor(applicationContext) { x, y ->
                    tiltState = TiltState(x, y)
                }
            }

            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    when (event) {
                        Lifecycle.Event.ON_START -> tiltSensor.start()
                        Lifecycle.Event.ON_STOP -> tiltSensor.stop()
                        else -> Unit
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                    tiltSensor.stop()
                }
            }

            val stats by tracker.statsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
            val statsMap = remember(stats) { stats.associateBy { it.lessonId } }
            val suggestion = remember(stats) { tracker.pickSuggestedReview(stats) }

            var route by rememberSaveable { mutableStateOf(AppRoute.HOME) }
            var selectedSubject by rememberSaveable { mutableStateOf(Subject.PHYSICS) }
            var selectedLessonId by rememberSaveable {
                mutableStateOf(LessonRepository.allLessons.first().id)
            }
            var isVideoFullscreen by rememberSaveable { mutableStateOf(false) }
            var savedPin by remember { mutableStateOf(PinStore.load(applicationContext)) }

            val currentLesson = remember(selectedLessonId, selectedSubject) {
                LessonRepository.findById(selectedLessonId)
                    ?: LessonRepository.bySubject(selectedSubject).firstOrNull()
                    ?: LessonRepository.allLessons.first()
            }

            LaunchedEffect(isVideoFullscreen, route) {
                val activeFullscreen = isVideoFullscreen && route == AppRoute.LESSONS
                applyFullscreenMode(activeFullscreen)
            }

            LaunchedEffect(route) {
                if (route == AppRoute.FOCUS) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    runCatching {
                        val am = getSystemService(ACTIVITY_SERVICE) as? ActivityManager
                        if (am?.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_NONE) {
                            startLockTask()
                        }
                    }
                } else {
                    if (!isVideoFullscreen) {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                    runCatching { stopLockTask() }
                }
            }

            val showBottomBar = route in setOf(
                AppRoute.HOME,
                AppRoute.LESSONS,
                AppRoute.PROGRESS,
                AppRoute.ACCOUNT
            ) && !isVideoFullscreen

            CompositionLocalProvider(
                LocalLayoutDirection provides LayoutDirection.Rtl,
                LocalTiltState provides tiltState
            ) {
                Scaffold(
                    containerColor = ForestTokens.BlackOled,
                    bottomBar = {
                        if (showBottomBar) {
                            GlassBottomBar(
                                currentRoute = route,
                                onSelectTab = { tab: MainTab ->
                                    isVideoFullscreen = false
                                    route = tab.route
                                }
                            )
                        }
                    }
                ) { innerPadding: PaddingValues ->
                    val effectiveBottom = if (showBottomBar) innerPadding else PaddingValues(0.dp)

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ForestTokens.BlackOled)
                    ) {
                        AnimatedContent(
                            targetState = route,
                            transitionSpec = { ForestMotion.screenTransition },
                            label = "mainRoute"
                        ) { targetRoute ->
                            when (targetRoute) {
                                AppRoute.HOME -> HomeScreen(
                                    suggestion = suggestion,
                                    onOpenSearch = { route = AppRoute.SEARCH },
                                    onOpenLesson = { lesson ->
                                        selectedSubject = lesson.subject
                                        selectedLessonId = lesson.id
                                        route = AppRoute.LESSONS
                                    },
                                    onSelectSubject = { subject ->
                                        selectedSubject = subject
                                        LessonRepository.bySubject(subject).firstOrNull()?.let {
                                            selectedLessonId = it.id
                                        }
                                        route = AppRoute.LESSONS
                                    },
                                    bottomPadding = effectiveBottom
                                )

                                AppRoute.LESSONS -> LessonScreen(
                                    subject = selectedSubject,
                                    currentLesson = currentLesson,
                                    statsMap = statsMap,
                                    isFullscreen = isVideoFullscreen,
                                    onFullscreenChange = { isVideoFullscreen = it },
                                    onSelectSubject = { subject ->
                                        selectedSubject = subject
                                        LessonRepository.bySubject(subject).firstOrNull()?.let {
                                            selectedLessonId = it.id
                                        }
                                    },
                                    onSelectLesson = { lesson ->
                                        selectedLessonId = lesson.id
                                    },
                                    onStartFocus = {
                                        isVideoFullscreen = false
                                        route = AppRoute.FOCUS
                                    },
                                    onTickStudySecond = { lesson ->
                                        scope.launch {
                                            tracker.recordStudyProgress(lesson, addedSeconds = 15L)
                                        }
                                    },
                                    onMarkCompleted = { lesson ->
                                        scope.launch {
                                            tracker.recordStudyProgress(
                                                lesson,
                                                addedSeconds = 60L,
                                                markCompleted = true
                                            )
                                        }
                                    },
                                    onBack = {
                                        isVideoFullscreen = false
                                        route = AppRoute.HOME
                                    },
                                    bottomPadding = effectiveBottom
                                )

                                AppRoute.PROGRESS -> ProgressScreen(
                                    stats = stats,
                                    suggestion = suggestion,
                                    onOpenLesson = { lesson ->
                                        selectedSubject = lesson.subject
                                        selectedLessonId = lesson.id
                                        route = AppRoute.LESSONS
                                    },
                                    bottomPadding = effectiveBottom
                                )

                                AppRoute.ACCOUNT -> AccountScreen(
                                    currentPin = savedPin,
                                    onUpdatePin = { newPin ->
                                        PinStore.save(applicationContext, newPin)
                                        savedPin = newPin
                                    },
                                    onResetProgress = {
                                        scope.launch { tracker.resetAll() }
                                    },
                                    bottomPadding = effectiveBottom
                                )

                                AppRoute.SEARCH -> SearchScreen(
                                    laws = physicsLaws,
                                    onOpenLessonById = { lessonId ->
                                        LessonRepository.findById(lessonId)?.let { lesson ->
                                            selectedSubject = lesson.subject
                                            selectedLessonId = lesson.id
                                            route = AppRoute.LESSONS
                                        }
                                    },
                                    onBack = { route = AppRoute.HOME }
                                )

                                AppRoute.FOCUS -> FocusScreen(
                                    lesson = currentLesson,
                                    savedPin = savedPin,
                                    onExitFocus = { route = AppRoute.LESSONS },
                                    onOpenDecoy = { route = AppRoute.DECOY }
                                )

                                AppRoute.DECOY -> DecoyScreen(
                                    secretPin = savedPin,
                                    onUnlockSuccess = { route = AppRoute.HOME }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun applyFullscreenMode(enable: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        val isCompactPhone = resources.configuration.smallestScreenWidthDp < 600
        if (enable) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            if (isCompactPhone) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            controller.show(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
}
