package com.forestglass.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.forestglass.data.Lesson
import com.forestglass.data.LessonRepository
import com.forestglass.data.ReviewSuggestion
import com.forestglass.data.StudyStatEntity
import com.forestglass.data.Subject
import com.forestglass.ui.glass.GlassCard
import com.forestglass.ui.glass.GlassTier
import com.forestglass.ui.glass.LocalWaterPulse
import com.forestglass.ui.theme.ForestMotion
import com.forestglass.ui.theme.ForestTokens
import com.forestglass.ui.theme.fluidRise

@Composable
fun ProgressScreen(
    stats: List<StudyStatEntity>,
    suggestion: ReviewSuggestion,
    onOpenLesson: (Lesson) -> Unit,
    bottomPadding: PaddingValues,
    modifier: Modifier = Modifier
) {
    val waterPulse = LocalWaterPulse.current
    val statsMap = stats.associateBy { it.lessonId }
    val totalMinutes = stats.sumOf { it.watchSeconds } / 60L
    val completedLessons = stats.count { it.completedCount > 0 }
    val avgMastery = if (LessonRepository.allLessons.isEmpty()) 0 else {
        ((LessonRepository.allLessons.sumOf { (statsMap[it.id]?.masteryScore ?: 0f).toDouble() } /
            LessonRepository.allLessons.size) * 100).toInt()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = ForestTokens.ScreenPadding),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 860.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(
                top = 18.dp,
                bottom = bottomPadding.calculateBottomPadding() + 18.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "تقدمي الدراسي",
                    color = ForestTokens.TextPrimary,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fluidRise(0)
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth().fluidRise(1),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatTile("نسبة الإتقان", "$avgMastery%", Modifier.weight(1f))
                    StatTile("دروس منجزة", "$completedLessons / ${LessonRepository.allLessons.size}", Modifier.weight(1f))
                    StatTile("دقائق الدراسة", "$totalMinutes د", Modifier.weight(1f))
                }
            }

            item {
                GlassCard(
                    cornerRadius = ForestTokens.CardRadius,
                    selected = true,
                    onClick = {
                        waterPulse.emit(0.5f, 0.36f, 0.85f)
                        onOpenLesson(suggestion.lesson)
                    },
                    modifier = Modifier.fillMaxWidth().fluidRise(2)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "الأولوية القادمة في المراجعة",
                            color = ForestTokens.MintGlow,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = suggestion.lesson.title,
                            color = ForestTokens.TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "${suggestion.lesson.subject.titleAr} · ${suggestion.statusLabel}",
                            color = ForestTokens.TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            items(Subject.entries, key = { it.name }) { subject ->
                val subjectLessons = LessonRepository.bySubject(subject)
                val done = subjectLessons.count { (statsMap[it.id]?.completedCount ?: 0) > 0 }
                val ratio = if (subjectLessons.isEmpty()) 0f else done.toFloat() / subjectLessons.size
                val animatedRatio by animateFloatAsState(
                    targetValue = ratio.coerceIn(0f, 1f),
                    animationSpec = ForestMotion.liquidSpring(),
                    label = "subjectBar"
                )

                GlassCard(
                    cornerRadius = 22.dp,
                    tier = GlassTier.Lite,
                    onClick = {
                        waterPulse.emit(0.5f, 0.58f + subject.ordinal * 0.08f, 0.78f)
                        subjectLessons.firstOrNull()?.let(onOpenLesson)
                    },
                    modifier = Modifier.fillMaxWidth().animateItem().fluidRise(3 + subject.ordinal)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = subject.titleAr,
                                color = ForestTokens.TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "$done من ${subjectLessons.size}",
                                color = ForestTokens.MintGlow,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(ForestTokens.MintBadge)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(animatedRatio)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(ForestTokens.MintGlow)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    GlassCard(
        cornerRadius = 20.dp,
        tier = GlassTier.Lite,
        interactive = false,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                color = ForestTokens.MintGlow,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = label,
                color = ForestTokens.TextSecondary,
                fontSize = 11.sp
            )
        }
    }
}
