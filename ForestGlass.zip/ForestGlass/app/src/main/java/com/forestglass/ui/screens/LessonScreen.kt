package com.forestglass.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.movableContentOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.forestglass.data.Lesson
import com.forestglass.data.LessonRepository
import com.forestglass.data.PhysicsIndex
import com.forestglass.data.StudyStatEntity
import com.forestglass.data.Subject
import com.forestglass.player.YouTubeLessonPlayer
import com.forestglass.ui.glass.GlassCard
import com.forestglass.ui.glass.GlassSelectableRow
import com.forestglass.ui.glass.GlassTier
import com.forestglass.ui.glass.LocalWaterPulse
import com.forestglass.ui.theme.FIcon
import com.forestglass.ui.theme.ForestIcon
import com.forestglass.ui.theme.ForestTokens
import com.forestglass.ui.theme.fluidRise
import kotlinx.coroutines.delay

@Composable
fun LessonScreen(
    subject: Subject,
    currentLesson: Lesson,
    statsMap: Map<String, StudyStatEntity>,
    isFullscreen: Boolean,
    onFullscreenChange: (Boolean) -> Unit,
    onSelectSubject: (Subject) -> Unit,
    onSelectLesson: (Lesson) -> Unit,
    onStartFocus: () -> Unit,
    onTickStudySecond: (Lesson) -> Unit,
    onMarkCompleted: (Lesson) -> Unit,
    onBack: () -> Unit,
    bottomPadding: PaddingValues,
    modifier: Modifier = Modifier
) {
    val waterPulse = LocalWaterPulse.current
    val lessons = remember(subject) { LessonRepository.bySubject(subject) }
    val latestLesson by rememberUpdatedState(currentLesson)
    val relatedLaws = remember(currentLesson.id) {
        PhysicsIndex.fallbackLaws.filter { it.id in currentLesson.relatedLawIds }
    }

    LaunchedEffect(currentLesson.id) {
        while (true) {
            delay(15_000L)
            onTickStudySecond(latestLesson)
        }
    }

    BackHandler(enabled = isFullscreen) {
        onFullscreenChange(false)
    }

    val sharedPlayer = remember(currentLesson.id) {
        movableContentOf { fullscreen: Boolean, playerModifier: Modifier ->
            YouTubeLessonPlayer(
                youtubeId = currentLesson.youtubeId,
                lessonTitle = currentLesson.title,
                isFullscreen = fullscreen,
                onToggleFullscreen = { onFullscreenChange(!fullscreen) },
                modifier = playerModifier
            )
        }
    }

    if (isFullscreen) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            sharedPlayer(true, Modifier.fillMaxSize())
        }
        return
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = ForestTokens.ScreenPadding)
            .padding(bottom = bottomPadding.calculateBottomPadding()),
        contentAlignment = Alignment.TopCenter
    ) {
        val isTabletWide = maxWidth >= 600.dp

        Column(
            modifier = Modifier
                .widthIn(max = 1080.dp)
                .fillMaxSize()
                .padding(top = 12.dp, bottom = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().fluidRise(0),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Subject.entries.forEachIndexed { idx, item ->
                        val active = item == subject
                        GlassCard(
                            cornerRadius = 18.dp,
                            tier = GlassTier.Lite,
                            selected = active,
                            onClick = {
                                waterPulse.emit(0.2f + idx * 0.18f, 0.12f, 0.7f)
                                onSelectSubject(item)
                            }
                        ) {
                            Text(
                                text = item.titleAr,
                                color = if (active) ForestTokens.MintGlow else ForestTokens.TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                GlassCard(
                    cornerRadius = 18.dp,
                    tier = GlassTier.Lite,
                    onClick = {
                        waterPulse.emit(0.88f, 0.12f, 0.65f)
                        onBack()
                    }
                ) {
                    Box(
                        modifier = Modifier.padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        ForestIcon(FIcon.BACK, size = 18.dp, tint = ForestTokens.TextPrimary)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            if (isTabletWide) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(0.41f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        LessonListCard(
                            lessons = lessons,
                            selectedId = currentLesson.id,
                            statsMap = statsMap,
                            onSelectLesson = {
                                waterPulse.emit(0.32f, 0.55f, 0.68f)
                                onSelectLesson(it)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .fluidRise(1)
                        )
                        Spacer(Modifier.height(12.dp))
                        FocusLaunchButton(
                            onStartFocus = {
                                waterPulse.emit(0.32f, 0.88f, 0.85f)
                                onStartFocus()
                            },
                            modifier = Modifier.fluidRise(3)
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(0.59f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        GlassCard(
                            cornerRadius = 24.dp,
                            interactive = false,
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(16f / 9f)
                                .fluidRise(1)
                        ) {
                            sharedPlayer(false, Modifier.fillMaxSize())
                        }

                        LessonMetaRow(
                            lesson = currentLesson,
                            isCompleted = (statsMap[currentLesson.id]?.completedCount ?: 0) > 0,
                            onToggleFullscreen = {
                                waterPulse.emit(0.75f, 0.52f, 0.72f)
                                onFullscreenChange(true)
                            },
                            onMarkCompleted = {
                                waterPulse.emit(0.62f, 0.52f, 0.82f)
                                onMarkCompleted(currentLesson)
                            },
                            modifier = Modifier.fluidRise(2)
                        )

                        LessonSummaryCard(
                            lesson = currentLesson,
                            relatedLawsCount = relatedLaws.size,
                            firstLawFormula = relatedLaws.firstOrNull()?.let { "${it.title}: ${it.formula}" },
                            modifier = Modifier.fillMaxWidth().fluidRise(3)
                        )
                    }
                }
            } else {
                GlassCard(
                    cornerRadius = 24.dp,
                    interactive = false,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .fluidRise(1)
                ) {
                    sharedPlayer(false, Modifier.fillMaxSize())
                }

                Spacer(Modifier.height(10.dp))

                LessonMetaRow(
                    lesson = currentLesson,
                    isCompleted = (statsMap[currentLesson.id]?.completedCount ?: 0) > 0,
                    onToggleFullscreen = {
                        waterPulse.emit(0.78f, 0.44f, 0.72f)
                        onFullscreenChange(true)
                    },
                    onMarkCompleted = {
                        waterPulse.emit(0.58f, 0.44f, 0.82f)
                        onMarkCompleted(currentLesson)
                    },
                    modifier = Modifier.fluidRise(2)
                )

                Spacer(Modifier.height(10.dp))

                LessonListCard(
                    lessons = lessons,
                    selectedId = currentLesson.id,
                    statsMap = statsMap,
                    onSelectLesson = {
                        waterPulse.emit(0.5f, 0.68f, 0.68f)
                        onSelectLesson(it)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .fluidRise(3)
                )

                Spacer(Modifier.height(10.dp))

                FocusLaunchButton(
                    onStartFocus = {
                        waterPulse.emit(0.5f, 0.90f, 0.85f)
                        onStartFocus()
                    },
                    modifier = Modifier.fluidRise(4)
                )
            }
        }
    }
}

@Composable
private fun LessonSummaryCard(
    lesson: Lesson,
    relatedLawsCount: Int,
    firstLawFormula: String?,
    modifier: Modifier = Modifier
) {
    GlassCard(
        cornerRadius = 18.dp,
        tier = GlassTier.Lite,
        interactive = false,
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = lesson.chapter,
                    color = ForestTokens.MintGlow,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (relatedLawsCount > 0) {
                    Text(
                        text = "$relatedLawsCount قوانين مرتبطة",
                        color = ForestTokens.TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier
                            .background(ForestTokens.MintBadge, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Spacer(Modifier.height(5.dp))
            Text(
                text = lesson.summary,
                color = ForestTokens.TextSecondary,
                fontSize = 13.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (firstLawFormula != null) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = firstLawFormula,
                    color = ForestTokens.GlassSpecular,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun LessonMetaRow(
    lesson: Lesson,
    isCompleted: Boolean,
    onToggleFullscreen: () -> Unit,
    onMarkCompleted: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = lesson.title,
                color = ForestTokens.TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = "${lesson.teacher} · ${lesson.durationMinutes} د",
                color = ForestTokens.TextSecondary,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(Modifier.width(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassCard(
                cornerRadius = 14.dp,
                tier = GlassTier.Lite,
                selected = isCompleted,
                onClick = onMarkCompleted
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ForestIcon(
                        icon = FIcon.CHECK,
                        size = 16.dp,
                        tint = if (isCompleted) ForestTokens.MintGlow else ForestTokens.TextSecondary
                    )
                    Text(
                        text = if (isCompleted) "مُنجز" else "إتمام",
                        color = if (isCompleted) ForestTokens.MintGlow else ForestTokens.TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            GlassCard(
                cornerRadius = 14.dp,
                tier = GlassTier.Lite,
                onClick = onToggleFullscreen
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ForestIcon(
                        icon = FIcon.FULLSCREEN,
                        size = 16.dp,
                        tint = ForestTokens.TextPrimary
                    )
                    Text(
                        text = "ملء الشاشة",
                        color = ForestTokens.TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
private fun LessonListCard(
    lessons: List<Lesson>,
    selectedId: String,
    statsMap: Map<String, StudyStatEntity>,
    onSelectLesson: (Lesson) -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        cornerRadius = ForestTokens.CardRadius,
        interactive = false,
        modifier = modifier
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(lessons, key = { it.id }) { item ->
                val isSelected = item.id == selectedId
                val completed = (statsMap[item.id]?.completedCount ?: 0) > 0

                GlassSelectableRow(
                    selected = isSelected,
                    onClick = { onSelectLesson(item) },
                    modifier = Modifier.fillMaxWidth().animateItem()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                color = if (isSelected) ForestTokens.MintGlow else ForestTokens.TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = item.chapter,
                                color = ForestTokens.TextMuted,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (completed) {
                            Spacer(Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .background(ForestTokens.MintBadge, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                ForestIcon(FIcon.CHECK, size = 13.dp, tint = ForestTokens.MintGlow)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FocusLaunchButton(
    onStartFocus: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        cornerRadius = 22.dp,
        selected = true,
        onClick = onStartFocus,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 15.dp, horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            ForestIcon(FIcon.LOCK, size = 19.dp, tint = ForestTokens.MintGlow)
            Spacer(Modifier.width(8.dp))
            Text(
                text = "ابدأ وضع التركيز",
                color = ForestTokens.TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
