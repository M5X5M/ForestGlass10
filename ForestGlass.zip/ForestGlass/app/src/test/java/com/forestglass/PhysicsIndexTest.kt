package com.forestglass

import com.forestglass.data.PhysicsIndex
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PhysicsIndexTest {
    @Test
    fun arabicNormalizationStripsTashkeelAndUnifiesAlef() {
        val norm = PhysicsIndex.normalizeArabic("قَانُونُ أُومَ وَالمُقَاوَمَةُ")
        assertEquals("قانون اوم والمقاومه", norm)
    }

    @Test
    fun fuzzySearchFindsKirchhoffEvenWithTypo() {
        val results = PhysicsIndex.search("كرشوف", PhysicsIndex.fallbackLaws)
        assertTrue(results.isNotEmpty())
        assertTrue(results.first().law.title.contains("كيرشوف"))
    }
}
