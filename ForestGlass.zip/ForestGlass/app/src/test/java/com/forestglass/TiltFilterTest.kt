package com.forestglass

import com.forestglass.sensor.TiltFilter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class TiltFilterTest {
    @Test
    fun deadzoneKeepsSmallHandJitterAtZero() {
        val filter = TiltFilter()
        filter.step(0f, 0f, 1f / 60f)
        val out = filter.step(0.004f, -0.005f, 1f / 60f)
        assertEquals(0f, out.x, 1e-4f)
        assertEquals(0f, out.y, 1e-4f)
    }

    @Test
    fun largeTiltRemainsBoundedInsideUnitRange() {
        val filter = TiltFilter()
        filter.step(0f, 0f, 1f / 60f)
        var lastX = 0f
        repeat(40) {
            lastX = filter.step(1.2f, 0f, 1f / 60f).x
        }
        assertTrue(abs(lastX) in 0.05f..1.0f)
    }
}
